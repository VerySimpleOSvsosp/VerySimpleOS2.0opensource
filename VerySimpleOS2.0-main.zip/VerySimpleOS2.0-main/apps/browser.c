#include "browser.h"
#include "graphics.h"
#include "window.h"
#include "network.h"
#include "stdio.h"
#include "string.h"

void open_browser_window() {
    uint8_t window_id = create_window(40, 20, 280, 200, "VerySimple Browser");
    
    if (window_id == 255) return;
    
    // Панель адреса
    draw_rect(windows[window_id].x + 2, windows[window_id].y + 20, 276, 16, 15);
    draw_text(windows[window_id].x + 4, windows[window_id].y + 22, "Address: http://", 0);
    
    // Кнопки навигации
    draw_button(windows[window_id].x + 4, windows[window_id].y + 40, 40, 16, "Back");
    draw_button(windows[window_id].x + 48, windows[window_id].y + 40, 40, 16, "Forward");
    draw_button(windows[window_id].x + 92, windows[window_id].y + 40, 40, 16, "Refresh");
    
    // Область содержимого
    draw_rect(windows[window_id].x + 2, windows[window_id].y + 60, 276, 118, 15);
    
    // Статус бар
    draw_rect(windows[window_id].x + 2, windows[window_id].y + 182, 276, 16, 248);
    draw_text(windows[window_id].x + 4, windows[window_id].y + 184, "Ready", 0);
    
    // Демонстрационное содержимое
    draw_text(windows[window_id].x + 10, windows[window_id].y + 70, "Welcome to VerySimple Browser!", 0);
    draw_text(windows[window_id].x + 10, windows[window_id].y + 85, "This is a simple web browser.", 0);
    draw_text(windows[window_id].x + 10, windows[window_id].y + 100, "Type a URL in the address bar.", 0);
    
    printf("Web Browser opened\n");
}

void browser_navigate(const char* url) {
    printf("Browser navigating to: %s\n", url);
    
    uint16_t sock = create_socket(80);
    
    if (connect_socket(sock, 0xC0A80101, 80)) { // 192.168.1.1
        char http_request[256];
        sprintf(http_request, "GET / HTTP/1.0\r\nHost: %s\r\n\r\n", url);
        send_data(sock, (uint8_t*)http_request, strlen(http_request));
        
        uint8_t response[4096];
        uint16_t len = receive_data(sock, response, sizeof(response));
        
        if (len > 0) {
            display_webpage(response, len);
        }
    }
}

void display_webpage(uint8_t* data, uint16_t len) {
    char* html = (char*)data;
    char* body = strstr(html, "<body>");
    
    if (body) {
        body += 6;
        char* end_body = strstr(body, "</body>");
        
        if (end_body) {
            *end_body = '\0';
            
            char* pos = body;
            while (*pos) {
                if (*pos == '<') {
                    while (*pos && *pos != '>') pos++;
                    if (*pos == '>') pos++;
                } else {
                    char str[2] = {*pos, '\0'};
                    browser_putchar(str[0]);
                    pos++;
                }
            }
        }
    }
}

void browser_putchar(char c) {
    // Вывод символа в браузер (упрощенно)
    printf("%c", c);
}

void draw_button(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const char* text) {
    draw_rect(x, y, w, h, 248);
    draw_rect(x, y, w, 1, 15);
    draw_rect(x, y, 1, h, 15);
    draw_rect(x + w - 1, y, 1, h, 8);
    draw_rect(x, y + h - 1, w, 1, 8);
    
    uint16_t text_x = x + (w - strlen(text) * 8) / 2;
    uint16_t text_y = y + (h - 8) / 2;
    draw_text(text_x, text_y, text, 0);
}
