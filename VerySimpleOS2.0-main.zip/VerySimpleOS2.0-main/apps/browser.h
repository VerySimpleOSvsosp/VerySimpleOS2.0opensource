#ifndef BROWSER_H
#define BROWSER_H

#include "types.h"

void open_browser_window();
void browser_navigate(const char* url);
void display_webpage(uint8_t* data, uint16_t len);
void browser_putchar(char c);

#endif
