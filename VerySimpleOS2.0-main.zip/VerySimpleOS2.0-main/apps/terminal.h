#ifndef TERMINAL_H
#define TERMINAL_H

#include "types.h"

void open_terminal_window();
void terminal_print(const char* text);
void terminal_execute(const char* command);

#endif
