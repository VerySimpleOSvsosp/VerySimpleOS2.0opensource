#ifndef NETWORK_SETTINGS_H
#define NETWORK_SETTINGS_H

#include "types.h"

void open_network_settings();
void draw_network_settings_ui(uint8_t window_id);
void network_settings_handle_input(uint8_t window_id, char key);

#endif
