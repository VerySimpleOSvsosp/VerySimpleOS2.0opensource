#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include "types.h"

void open_filemanager_window();
void draw_filemanager_ui(uint8_t window_id);
void filemanager_handle_click(uint8_t window_id, uint16_t x, uint16_t y);

#endif
