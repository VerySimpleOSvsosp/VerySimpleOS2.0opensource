#ifndef CALCULATOR_H
#define CALCULATOR_H

#include "types.h"

void open_calculator_window();
void draw_calculator_ui(uint8_t window_id);
void calculator_handle_click(uint8_t window_id, uint16_t x, uint16_t y);

#endif
