#ifndef NOTEPAD_H
#define NOTEPAD_H

#include "types.h"

void open_notepad_window();
void draw_notepad_ui(uint8_t window_id);
void notepad_handle_input(uint8_t window_id, char key);

#endif
