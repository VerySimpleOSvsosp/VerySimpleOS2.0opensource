#ifndef MEDIAPLAYER_H
#define MEDIAPLAYER_H

#include "types.h"

void open_media_player();
void play_media_file(const char* filename);
void mediaplayer_handle_click(uint8_t window_id, uint16_t x, uint16_t y);

#endif
