#include "terminal.h"
#include "graphics.h"
#include "window.h"
#include "stdio.h"
#include "string.h"

static char terminal_buffer[1024];
static uint16_t terminal_pos = 0;

void open_terminal_window() {
    uint8_t window_id = create_window(40, 20, 280, 200, "Network Terminal");
    
    if (window_id == 255) return;
    
    // Область вывода
    draw_rect(windows[window_id].x + 2, windows[window_id].y + 20, 276, 160, 0);
    
    // Командная строка
    draw_rect(windows[window_id].x + 2, windows[window_id].y + 184, 276, 16, 8);
    draw_text(windows[window_id].x + 4, windows[window_id].y + 186, "C:\\> ", 15);
    
    terminal_print("VerySimpleOS Terminal v1.0\n");
    terminal_print("Type 'help' for commands\n");
    
    printf("Terminal opened\n");
}

void terminal_print(const char* text) {
    // Вывод текста в терминал (упрощенно)
    printf("%s", text);
    
    // Сохранение в буфер для отображения в окне
    if (terminal_pos + strlen(text) < sizeof(terminal_buffer) - 1) {
        strcpy(terminal_buffer + terminal_pos, text);
        terminal_pos += strlen(text);
    }
}

void terminal_execute(const char* command) {
    terminal_print("C:\\> ");
    terminal_print(command);
    terminal_print("\n");
    
    if (strcmp(command, "help") == 0) {
        terminal_print("Available commands:\n");
        terminal_print("  help     - Show this help\n");
        terminal_print("  ver      - Show system version\n");
        terminal_print("  time     - Show current time\n");
        terminal_print("  network  - Show network status\n");
        terminal_print("  clear    - Clear terminal\n");
    } else if (strcmp(command, "ver") == 0) {
        terminal_print("VerySimpleOS v1.0 (Windows 96 Edition)\n");
    } else if (strcmp(command, "time") == 0) {
        terminal_print("Current time: 12:00 PM\n");
    } else if (strcmp(command, "network") == 0) {
        terminal_print("Network status: Online\n");
        terminal_print("IP address: 192.168.1.100\n");
    } else if (strcmp(command, "clear") == 0) {
        terminal_pos = 0;
        terminal_buffer[0] = '\0';
    } else {
        terminal_print("Unknown command. Type 'help' for available commands.\n");
    }
}
