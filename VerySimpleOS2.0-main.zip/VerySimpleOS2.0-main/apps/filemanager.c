#include "filemanager.h"
#include "graphics.h"
#include "window.h"
#include "filesystem.h"
#include "stdio.h"
#include "string.h"

void open_filemanager_window() {
    uint8_t window_id = create_window(30, 20, 260, 180, "File Manager - C:\\");
    
    if (window_id == 255) return;
    
    draw_filemanager_ui(window_id);
    printf("File Manager opened\n");
}

void draw_filemanager_ui(uint8_t window_id) {
    window_t* win = &windows[window_id];
    
    // Панель инструментов
    draw_rect(win->x + 2, win->y + 20, win->width - 4, 20, WIN96_WINDOW_BG);
    draw_text(win->x + 5, win->y + 25, "Up  Copy  Move  Delete  View", WIN96_TEXT_BLACK);
    
    // Область файлов
    draw_rect(win->x + 2, win->y + 45, win->width - 4, win->height - 65, 15);
    
    // Список файлов
    draw_text(win->x + 5, win->y + 50, "C:", WIN96_TEXT_BLACK);
    draw_text(win->x + 5, win->y + 65, "System", WIN96_TEXT_BLACK);
    draw_text(win->x + 5, win->y + 80, "Programs", WIN96_TEXT_BLACK);
    draw_text(win->x + 5, win->y + 95, "Documents", WIN96_TEXT_BLACK);
    draw_text(win->x + 5, win->y + 110, "Autoexec.bat", WIN96_TEXT_BLACK);
    draw_text(win->x + 5, win->y + 125, "Config.sys", WIN96_TEXT_BLACK);
    
    // Статус бар
    draw_rect(win->x + 2, win->y + win->height - 15, win->width - 4, 13, WIN96_WINDOW_BG);
    draw_text(win->x + 5, win->y + win->height - 12, "6 objects", WIN96_TEXT_BLACK);
}

void filemanager_handle_click(uint8_t window_id, uint16_t x, uint16_t y) {
    window_t* win = &windows[window_id];
    
    if (y >= win->y + 50 && y <= win->y + 130) {
        int item = (y - win->y - 50) / 15;
        
        const char* items[] = {"C:", "System", "Programs", "Documents", "Autoexec.bat", "Config.sys"};
        if (item >= 0 && item < 6) {
            printf("File Manager: %s selected\n", items[item]);
        }
    }
}
