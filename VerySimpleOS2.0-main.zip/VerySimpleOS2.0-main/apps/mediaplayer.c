#include "mediaplayer.h"
#include "graphics.h"
#include "window.h"
#include "sound.h"
#include "stdio.h"
#include "string.h"

void open_media_player() {
    uint8_t window_id = create_window(80, 60, 200, 150, "Media Player");
    
    if (window_id == 255) return;
    
    // Элементы управления
    draw_button(windows[window_id].x + 20, windows[window_id].y + 30, 40, 20, "Play");
    draw_button(windows[window_id].x + 70, windows[window_id].y + 30, 40, 20, "Stop");
    draw_button(windows[window_id].x + 120, windows[window_id].y + 30, 40, 20, "Pause");
    
    // Полоса прогресса
    draw_rect(windows[window_id].x + 20, windows[window_id].y + 60, 160, 10, 248);
    draw_rect(windows[window_id].x + 20, windows[window_id].y + 60, 80, 10, 31);
    
    // Информация о треке
    draw_text(windows[window_id].x + 20, windows[window_id].y + 80, "Now playing: startup.wav", 0);
    draw_text(windows[window_id].x + 20, windows[window_id].y + 95, "00:25 / 01:00", 0);
    
    // Громкость
    draw_text(windows[window_id].x + 20, windows[window_id].y + 115, "Volume:", 0);
    draw_rect(windows[window_id].x + 70, windows[window_id].y + 115, 100, 10, 248);
    draw_rect(windows[window_id].x + 70, windows[window_id].y + 115, 75, 10, 31);
    
    printf("Media Player opened\n");
}

void play_media_file(const char* filename) {
    printf("Media Player: Playing %s\n", filename);
    
    // В реальности здесь была бы загрузка и воспроизведение файла
    play_system_sound(SOUND_STARTUP);
}

void mediaplayer_handle_click(uint8_t window_id, uint16_t x, uint16_t y) {
    window_t* win = &windows[window_id];
    
    if (y >= win->y + 30 && y <= win->y + 50) {
        if (x >= win->x + 20 && x <= win->x + 60) {
            printf("Media Player: Play pressed\n");
            play_media_file("startup.wav");
        } else if (x >= win->x + 70 && x <= win->x + 110) {
            printf("Media Player: Stop pressed\n");
            stop_sound();
        } else if (x >= win->x + 120 && x <= win->x + 160) {
            printf("Media Player: Pause pressed\n");
            // Реализация паузы
        }
    }
}
