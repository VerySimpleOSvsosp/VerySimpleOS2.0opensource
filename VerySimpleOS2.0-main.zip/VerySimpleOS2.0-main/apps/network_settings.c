#include "network_settings.h"
#include "graphics.h"
#include "window.h"
#include "network.h"
#include "stdio.h"
#include "string.h"

void open_network_settings() {
    uint8_t window_id = create_window(60, 40, 240, 160, "Network Settings");
    
    if (window_id == 255) return;
    
    draw_network_settings_ui(window_id);
    printf("Network Settings opened\n");
}

void draw_network_settings_ui(uint8_t window_id) {
    window_t* win = &windows[window_id];
    
    // Статус сети
    draw_text(win->x + 10, win->y + 25, "Network Status:", 0);
    if (net_config.connected) {
        draw_text(win->x + 100, win->y + 25, "Connected", 10);
    } else {
        draw_text(win->x + 100, win->y + 25, "Disconnected", 12);
    }
    
    // IP адрес
    draw_text(win->x + 10, win->y + 45, "IP Address:", 0);
    char ip_str[16];
    sprintf(ip_str, "%d.%d.%d.%d", 
           (net_config.ip >> 24) & 0xFF, (net_config.ip >> 16) & 0xFF,
           (net_config.ip >> 8) & 0xFF, net_config.ip & 0xFF);
    draw_text(win->x + 100, win->y + 45, ip_str, 0);
    
    // Настройки
    draw_text(win->x + 10, win->y + 65, "Configuration:", 0);
    draw_button(win->x + 100, win->y + 65, 60, 20, "DHCP");
    draw_button(win->x + 170, win->y + 65, 60, 20, "Static");
    
    // Кнопки
    draw_button(win->x + 50, win->y + 120, 60, 20, "Apply");
    draw_button(win->x + 130, win->y + 120, 60, 20, "Cancel");
}

void network_settings_handle_input(uint8_t window_id, char key) {
    // Обработка ввода в настройках сети
    printf("Network Settings: Key pressed - %c\n", key);
}
