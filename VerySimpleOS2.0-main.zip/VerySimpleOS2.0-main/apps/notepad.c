#include "notepad.h"
#include "graphics.h"
#include "window.h"
#include "stdio.h"
#include "string.h"

void open_notepad_window() {
    uint8_t window_id = create_window(50, 30, 250, 150, "Notepad - Untitled");
    
    if (window_id == 255) return;
    
    draw_notepad_ui(window_id);
    printf("Notepad opened\n");
}

void draw_notepad_ui(uint8_t window_id) {
    window_t* win = &windows[window_id];
    
    // Меню
    const char* menu_items[] = {"File", "Edit", "Search", "Help"};
    uint16_t menu_x = win->x + 4;
    
    for (int i = 0; i < 4; i++) {
        draw_text(menu_x, win->y + 18, menu_items[i], WIN96_TEXT_BLACK);
        menu_x += strlen(menu_items[i]) * 8 + 10;
    }
    
    // Текстовая область
    draw_rect(win->x + 2, win->y + 32, win->width - 4, win->height - 44, 15);
    
    // Полоса прокрутки
    draw_rect(win->x + win->width - 12, win->y + 32, 10, win->height - 44, WIN96_WINDOW_BG);
    
    // Строка статуса
    draw_rect(win->x, win->y + win->height - 12, win->width, 12, WIN96_WINDOW_BG);
    draw_text(win->x + 4, win->y + win->height - 10, "Ready", WIN96_TEXT_BLACK);
    
    // Пример текста
    draw_text(win->x + 6, win->y + 36, "Welcome to Notepad!", WIN96_TEXT_BLACK);
    draw_text(win->x + 6, win->y + 48, "This is a simple text editor.", WIN96_TEXT_BLACK);
}

void notepad_handle_input(uint8_t window_id, char key) {
    // Обработка ввода в блокноте
    // В реальной реализации здесь была бы логика редактирования текста
}
