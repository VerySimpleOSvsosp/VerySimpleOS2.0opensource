#include "calculator.h"
#include "graphics.h"
#include "window.h"
#include "stdio.h"
#include "string.h"

void open_calculator_window() {
    uint8_t window_id = create_window(100, 50, 150, 200, "Calculator");
    
    if (window_id == 255) return;
    
    draw_calculator_ui(window_id);
    printf("Calculator opened\n");
}

void draw_calculator_ui(uint8_t window_id) {
    window_t* win = &windows[window_id];
    
    // Дисплей
    draw_rect(win->x + 5, win->y + 25, win->width - 10, 20, 15);
    draw_text(win->x + 10, win->y + 30, "0", WIN96_TEXT_BLACK);
    
    // Кнопки калькулятора
    const char* buttons[] = {
        "7", "8", "9", "/",
        "4", "5", "6", "*", 
        "1", "2", "3", "-",
        "0", ".", "=", "+"
    };
    
    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 4; col++) {
            uint16_t x = win->x + 10 + col * 35;
            uint16_t y = win->y + 60 + row * 30;
            
            draw_rect(x, y, 30, 25, WIN96_WINDOW_BG);
            draw_rect(x, y, 30, 1, 15);
            draw_rect(x, y, 1, 25, 15);
            draw_rect(x + 29, y, 1, 25, 8);
            draw_rect(x, y + 24, 30, 1, 8);
            
            const char* label = buttons[row * 4 + col];
            uint16_t text_x = x + 15 - (strlen(label) * 4);
            draw_text(text_x, y + 8, label, WIN96_TEXT_BLACK);
        }
    }
}

void calculator_handle_click(uint8_t window_id, uint16_t x, uint16_t y) {
    window_t* win = &windows[window_id];
    
    // Проверка клика по кнопкам
    if (x >= win->x + 10 && x <= win->x + 150 && y >= win->y + 60 && y <= win->y + 180) {
        int col = (x - win->x - 10) / 35;
        int row = (y - win->y - 60) / 30;
        
        if (row >= 0 && row < 4 && col >= 0 && col < 4) {
            const char* buttons[] = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+"};
            const char* button = buttons[row * 4 + col];
            
            printf("Calculator button pressed: %s\n", button);
        }
    }
}
