#ifndef SYSTEM_CALLS_H
#define SYSTEM_CALLS_H

#include "types.h"

#define SYS_READ   0
#define SYS_WRITE  1
#define SYS_OPEN   2
#define SYS_CLOSE  3
#define SYS_EXEC   4
#define SYS_EXIT   5
#define SYS_FORK   6
#define SYS_WAIT   7

void syscall_init();
void syscall_handler();

#endif
