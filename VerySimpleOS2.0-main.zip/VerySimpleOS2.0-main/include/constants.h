#ifndef CONSTANTS_H
#define CONSTANTS_H

// Цвета Windows 96
enum win96_colors {
    WIN96_DESKTOP_BLUE = 17,
    WIN96_TASK_BAR = 248,
    WIN96_WINDOW_BG = 255,
    WIN96_TITLE_BLUE = 31,
    WIN96_TEXT_BLACK = 0,
    WIN96_TEXT_WHITE = 15
};

// Системные константы
#define VGA_WIDTH 320
#define VGA_HEIGHT 200
#define MAX_WINDOWS 10
#define MAX_PROCESSES 20

#endif
