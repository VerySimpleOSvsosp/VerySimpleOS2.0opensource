#!/bin/bash
echo "Starting VerySimpleOS in QEMU..."

# Проверяем наличие QEMU
if ! command -v qemu-system-i386 &> /dev/null; then
    echo "Error: qemu-system-i386 not found"
    echo "Please install QEMU first"
    exit 1
fi

# Проверяем наличие образа
if [ ! -f "verysimpleos.img" ]; then
    echo "Error: verysimpleos.img not found"
    echo "Please run 'make' first"
    exit 1
fi

# Запуск в QEMU
qemu-system-i386 \
    -drive file=verysimpleos.img,format=raw \
    -m 64M \
    -netdev user,id=net0 \
    -device ne2k_isa,netdev=net0 \
    -soundhw sb16 \
    -vga std \
    -monitor stdio

echo "QEMU session ended."
