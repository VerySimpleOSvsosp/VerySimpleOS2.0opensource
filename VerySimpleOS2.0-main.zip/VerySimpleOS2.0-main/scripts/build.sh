#!/bin/bash
echo "Building VerySimpleOS..."

# Создаем директорию для объектных файлов
mkdir -p obj/boot
mkdir -p obj/kernel
mkdir -p obj/kernel/drivers
mkdir -p obj/apps

# Компиляция загрузчиков
echo "Compiling bootloaders..."
nasm -f bin boot/mbr.asm -o obj/boot/mbr.bin
nasm -f bin boot/boot.asm -o obj/boot/boot.bin

# Компиляция ядра
echo "Compiling kernel..."
gcc -m32 -ffreestanding -nostdlib -nostartfiles -nodefaultlibs -Ikernel -Iinclude -c kernel/kernel.c -o obj/kernel/kernel.o
gcc -m32 -ffreestanding -nostdlib -nostartfiles -nodefaultlibs -Ikernel -Iinclude -c kernel/desktop.c -o obj/kernel/desktop.o
# ... компиляция всех остальных файлов ядра

# Компиляция драйверов
echo "Compiling drivers..."
gcc -m32 -ffreestanding -nostdlib -nostartfiles -nodefaultlibs -Ikernel -Iinclude -c kernel/drivers/ata.c -o obj/kernel/drivers/ata.o
# ... компиляция остальных драйверов

# Компиляция приложений
echo "Compiling applications..."
gcc -m32 -ffreestanding -nostdlib -nostartfiles -nodefaultlibs -Iapps -Iinclude -c apps/notepad.c -o obj/apps/notepad.o
# ... компиляция остальных приложений

# Линковка
echo "Linking..."
ld -m elf_i386 -T linker.ld -o obj/kernel.bin obj/kernel/*.o obj/kernel/drivers/*.o obj/apps/*.o

# Создание образа диска
echo "Creating disk image..."
dd if=/dev/zero of=verysimpleos.img bs=512 count=2880
dd if=obj/boot/mbr.bin of=verysimpleos.img conv=notrunc
dd if=obj/kernel.bin of=verysimpleos.img bs=512 seek=1 conv=notrunc

echo "Build complete: verysimpleos.img"
