#!/bin/bash
echo "VerySimpleOS Installer"
echo "======================"

if [ -z "$1" ]; then
    echo "Usage: $0 /dev/sdX"
    echo "WARNING: This will erase the target disk!"
    exit 1
fi

TARGET_DISK=$1

if [ ! -b "$TARGET_DISK" ]; then
    echo "Error: $TARGET_DISK is not a block device"
    exit 1
fi

echo "Target disk: $TARGET_DISK"
echo "Disk size: $(blockdev --getsize64 $TARGET_DISK) bytes"

read -p "Are you sure you want to install VerySimpleOS to $TARGET_DISK? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "Installation cancelled."
    exit 0
fi

# Сборка системы
echo "Building VerySimpleOS..."
make clean
make

if [ ! -f "verysimpleos.img" ]; then
    echo "Error: Build failed - verysimpleos.img not found"
    exit 1
fi

# Запись на диск
echo "Writing to disk..."
sudo dd if=verysimpleos.img of=$TARGET_DISK bs=1M status=progress

# Синхронизация
sync

echo "Installation complete!"
echo "You can now boot from $TARGET_DISK to start VerySimpleOS."
