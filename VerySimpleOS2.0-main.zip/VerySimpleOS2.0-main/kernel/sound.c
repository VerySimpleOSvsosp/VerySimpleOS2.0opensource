#include "sound.h"
#include "sb16.h"
#include "stdio.h"
#include "math.h"

audio_state_t audio;

void sound_init() {
    sb16_init();
    audio.sample_rate = 22050;
    audio.channels = 1;
    audio.bits_per_sample = 8;
    audio.playing = false;
    audio.position = 0;
    
    sb16_set_sample_rate(audio.sample_rate);
    printf("Sound system initialized: %d Hz, %d-bit, %d channels\n", 
           audio.sample_rate, audio.bits_per_sample, audio.channels);
}

void play_sound(uint8_t* wave_data, uint32_t length) {
    if (audio.playing) {
        sb16_stop_playback();
    }
    
    sb16_play_sample(wave_data, length);
    audio.playing = true;
    audio.position = 0;
}

void stop_sound() {
    sb16_stop_playback();
    audio.playing = false;
}

void play_system_sound(sound_type_t sound_type) {
    uint8_t beep_data[1000];
    
    switch (sound_type) {
        case SOUND_STARTUP:
            generate_sine_wave(beep_data, 1000, 440, 100);
            break;
        case SOUND_CLICK:
            generate_sine_wave(beep_data, 50, 880, 50);
            break;
        case SOUND_ERROR:
            generate_sine_wave(beep_data, 500, 220, 100);
            break;
        case SOUND_SHUTDOWN:
            generate_sine_wave(beep_data, 800, 1760, 150);
            break;
    }
    
    play_sound(beep_data, sizeof(beep_data));
}

void generate_sine_wave(uint8_t* buffer, uint32_t length, uint16_t frequency, uint8_t volume) {
    for (uint32_t i = 0; i < length; i++) {
        float sample = sin(2 * 3.14159 * frequency * i / audio.sample_rate);
        buffer[i] = 128 + (volume * sample);
    }
}

void sound_thread() {
    while (true) {
        if (audio.playing) {
            audio.position++;
            if (audio.position >= AUDIO_BUFFER_SIZE) {
                audio.playing = false;
            }
        }
        timer_wait(5);
    }
}
