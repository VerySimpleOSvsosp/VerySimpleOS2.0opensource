#include "window.h"
#include "graphics.h"
#include "stdio.h"
#include "string.h"

window_t windows[MAX_WINDOWS];
uint8_t window_count = 0;
uint8_t active_window = 0;

void window_init() {
    window_count = 0;
    active_window = 0;
}

uint8_t create_window(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const char* title) {
    if (window_count >= MAX_WINDOWS) return 255;
    
    windows[window_count].x = x;
    windows[window_count].y = y;
    windows[window_count].width = w;
    windows[window_count].height = h;
    strcpy(windows[window_count].title, title);
    windows[window_count].active = true;
    windows[window_count].minimized = false;
    windows[window_count].type = 0;
    windows[window_count].window_data = NULL;
    
    return window_count++;
}

void close_window(uint8_t id) {
    if (id < window_count) {
        windows[id].active = false;
    }
}

void draw_window_frame(uint8_t id) {
    window_t* win = &windows[id];
    
    draw_rect(win->x, win->y, win->width, win->height, WIN96_WINDOW_BG);
    draw_rect(win->x, win->y, win->width, 16, WIN96_TITLE_BLUE);
    draw_text(win->x + 4, win->y + 4, win->title, WIN96_TEXT_WHITE);
    
    draw_rect(win->x, win->y, win->width, 1, 15);
    draw_rect(win->x, win->y, 1, win->height, 15);
    draw_rect(win->x + win->width - 1, win->y, 1, win->height, 8);
    draw_rect(win->x, win->y + win->height - 1, win->width, 1, 8);
    
    draw_window_buttons(win->x + win->width - 45, win->y + 2);
}

void draw_window_buttons(uint16_t x, uint16_t y) {
    draw_rect(x, y, 12, 12, WIN96_WINDOW_BG);
    draw_rect(x, y, 12, 1, 15);
    draw_rect(x, y, 1, 12, 15);
    draw_rect(x+11, y, 1, 12, 8);
    draw_rect(x, y+11, 12, 1, 8);
    draw_text(x+4, y+2, "_", WIN96_TEXT_BLACK);
    
    draw_rect(x+15, y, 12, 12, WIN96_WINDOW_BG);
    draw_rect(x+15, y, 12, 1, 15);
    draw_rect(x+15, y, 1, 12, 15);
    draw_rect(x+26, y, 1, 12, 8);
    draw_rect(x+15, y+11, 12, 1, 8);
    draw_text(x+19, y+2, "□", WIN96_TEXT_BLACK);
    
    draw_rect(x+30, y, 12, 12, WIN96_WINDOW_BG);
    draw_rect(x+30, y, 12, 1, 15);
    draw_rect(x+30, y, 1, 12, 15);
    draw_rect(x+41, y, 1, 12, 8);
    draw_rect(x+30, y+11, 12, 1, 8);
    draw_text(x+34, y+2, "X", WIN96_TEXT_BLACK);
}

void window_draw_all() {
    for (int i = 0; i < window_count; i++) {
        if (windows[i].active && !windows[i].minimized) {
            draw_window_frame(i);
        }
    }
}

void activate_window(uint8_t id) {
    if (id < window_count) {
        active_window = id;
    }
}

bool is_point_in_window(uint8_t id, uint16_t x, uint16_t y) {
    if (id >= window_count || !windows[id].active) return false;
    
    window_t* win = &windows[id];
    return (x >= win->x && x <= win->x + win->width &&
            y >= win->y && y <= win->y + win->height);
}
