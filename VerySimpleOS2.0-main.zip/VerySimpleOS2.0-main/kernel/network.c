#include "network.h"
#include "ne2000.h"
#include "stdio.h"
#include "string.h"

network_config_t net_config;
socket_t sockets[MAX_SOCKETS];
uint8_t socket_count = 0;

void network_init() {
    ne2000_init();
    
    uint8_t default_mac[] = {0x52, 0x54, 0x00, 0x12, 0x34, 0x56};
    memcpy(net_config.mac, default_mac, 6);
    net_config.ip = 0xC0A80164;
    net_config.gateway = 0xC0A80101;
    net_config.netmask = 0xFFFFFF00;
    net_config.connected = network_detect_link();
    
    printf("Network initialized: %d.%d.%d.%d\n", 
           (net_config.ip >> 24) & 0xFF, (net_config.ip >> 16) & 0xFF,
           (net_config.ip >> 8) & 0xFF, net_config.ip & 0xFF);
}

bool network_detect_link() {
    // Упрощенная проверка связи
    return true;
}

uint16_t create_socket(uint16_t port) {
    if (socket_count >= MAX_SOCKETS) return 0xFFFF;
    
    sockets[socket_count].port = port;
    sockets[socket_count].connected = false;
    sockets[socket_count].buffer_len = 0;
    
    return socket_count++;
}

bool connect_socket(uint16_t socket_id, uint32_t ip, uint16_t port) {
    if (socket_id >= socket_count) return false;
    
    sockets[socket_id].remote_ip = ip;
    sockets[socket_id].remote_port = port;
    sockets[socket_id].connected = true;
    
    return true;
}

bool send_data(uint16_t socket_id, uint8_t* data, uint16_t len) {
    if (socket_id >= socket_count || !sockets[socket_id].connected) return false;
    
    uint8_t packet[1500];
    uint16_t packet_len = len + 40;
    
    memcpy(packet, &sockets[socket_id].remote_ip, 4);
    memcpy(packet + 4, &net_config.ip, 4);
    memcpy(packet + 40, data, len);
    
    return ne2000_send_packet(packet, packet_len);
}

uint16_t receive_data(uint16_t socket_id, uint8_t* buffer, uint16_t max_len) {
    if (socket_id >= socket_count) return 0;
    
    socket_t* sock = &sockets[socket_id];
    uint16_t copy_len = (sock->buffer_len < max_len) ? sock->buffer_len : max_len;
    
    memcpy(buffer, sock->buffer, copy_len);
    sock->buffer_len = 0;
    
    return copy_len;
}

void network_thread() {
    while (true) {
        uint8_t packet_buffer[NET_BUFFER_SIZE];
        uint16_t len = ne2000_receive_packet(packet_buffer);
        
        if (len > 0) {
            // Обработка сетевого пакета
            process_network_packet(packet_buffer, len);
        }
        
        timer_wait(10);
    }
}

void process_network_packet(uint8_t* packet, uint16_t len) {
    // Упрощенная обработка пакетов
    // В реальности здесь был бы парсинг Ethernet/IP/TCP заголовков
}
