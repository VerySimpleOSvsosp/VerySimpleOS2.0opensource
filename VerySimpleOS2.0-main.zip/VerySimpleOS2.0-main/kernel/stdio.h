#ifndef STDIO_H
#define STDIO_H

#include "types.h"

int printf(const char* format, ...);
int sprintf(char* str, const char* format, ...);
int putchar(int c);
int puts(const char* str);

#endif
