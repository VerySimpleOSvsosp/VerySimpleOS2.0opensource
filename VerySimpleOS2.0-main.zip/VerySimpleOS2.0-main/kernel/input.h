#ifndef INPUT_H
#define INPUT_H

#include "types.h"

void input_init();
void input_handle();
bool keyboard_getchar(char* c);
void mouse_get_position(uint16_t* x, uint16_t* y);
bool mouse_get_buttons(uint8_t* buttons);
void mouse_draw_cursor();

#endif
