#ifndef PROGRAMS_H
#define PROGRAMS_H

#include "types.h"

#define MAX_PROGRAMS 20
#define MAX_PROGRAM_NAME 32

typedef struct {
    char name[MAX_PROGRAM_NAME];
    char filename[64];
    void (*entry_point)();
    uint32_t memory_usage;
    bool installed;
    bool running;
} program_t;

typedef struct {
    program_t programs[MAX_PROGRAMS];
    uint32_t program_count;
    program_t* current_program;
} program_manager_t;

extern program_manager_t pm;

void pm_init();
bool install_program(const char* app_file, const char* program_name);
bool uninstall_program(const char* program_name);
void launch_program(const char* program_name);
void terminate_program(const char* program_name);
void create_default_config();

#endif
