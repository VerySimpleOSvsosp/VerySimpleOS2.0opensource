#include "stdio.h"
#include "string.h"
#include "graphics.h"

static char printf_buffer[1024];

int printf(const char* format, ...) {
    // Упрощенная реализация printf
    // В реальности здесь была бы обработка переменных аргументов
    const char* p = format;
    char* buf = printf_buffer;
    
    while (*p) {
        *buf++ = *p++;
    }
    *buf = '\0';
    
    // Вывод в системную консоль (упрощенно)
    draw_text(0, 0, printf_buffer, 15);
    return strlen(printf_buffer);
}

int sprintf(char* str, const char* format, ...) {
    // Упрощенная реализация sprintf
    strcpy(str, format);
    return strlen(str);
}

int putchar(int c) {
    // Вывод одного символа
    char str[2] = {c, '\0'};
    draw_text(0, 0, str, 15);
    return c;
}

int puts(const char* str) {
    // Вывод строки с переводом строки
    printf("%s\n", str);
    return strlen(str);
}
