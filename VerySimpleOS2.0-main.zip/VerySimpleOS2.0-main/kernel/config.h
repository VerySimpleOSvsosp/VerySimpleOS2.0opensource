#ifndef CONFIG_H
#define CONFIG_H

#include "types.h"

typedef struct {
    uint16_t window_x;
    uint16_t window_y;
    uint16_t window_width;
    uint16_t window_height;
    char window_title[32];
    bool window_visible;
} window_state_t;

typedef struct {
    uint16_t desktop_color;
    uint16_t screen_width;
    uint16_t screen_height;
    char installed_programs[20][32];
    uint32_t program_count;
    window_state_t windows[10];
    uint32_t window_count;
    uint32_t mouse_x;
    uint32_t mouse_y;
} system_state_t;

void save_system_state();
bool load_system_state();
void create_default_config();

#endif
