#ifndef NETWORK_H
#define NETWORK_H

#include "types.h"

#define NET_BUFFER_SIZE 2048
#define MAX_SOCKETS 10

typedef struct {
    uint8_t mac[6];
    uint32_t ip;
    uint32_t gateway;
    uint32_t netmask;
    bool connected;
} network_config_t;

typedef struct {
    uint16_t port;
    uint32_t remote_ip;
    uint16_t remote_port;
    bool connected;
    uint8_t buffer[NET_BUFFER_SIZE];
    uint16_t buffer_len;
} socket_t;

extern network_config_t net_config;
extern socket_t sockets[MAX_SOCKETS];
extern uint8_t socket_count;

void network_init();
bool network_detect_link();
uint16_t create_socket(uint16_t port);
bool connect_socket(uint16_t socket_id, uint32_t ip, uint16_t port);
bool send_data(uint16_t socket_id, uint8_t* data, uint16_t len);
uint16_t receive_data(uint16_t socket_id, uint8_t* buffer, uint16_t max_len);
void network_thread();

#endif
