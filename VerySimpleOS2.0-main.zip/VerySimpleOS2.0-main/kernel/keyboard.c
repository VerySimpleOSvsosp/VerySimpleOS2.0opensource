#include "keyboard.h"
#include "isr.h"
#include "stdio.h"

char keyboard_buffer[256];
uint8_t keyboard_buffer_pos = 0;

void keyboard_handler(struct regs *r) {
    uint8_t scancode = inb(0x60);
    
    if (scancode < 128) {
        char c = keyboard_get_scancode();
        if (keyboard_buffer_pos < sizeof(keyboard_buffer) - 1) {
            keyboard_buffer[keyboard_buffer_pos++] = c;
        }
    }
}

void keyboard_init() {
    isr_install_handler(33, keyboard_handler);
    printf("Keyboard initialized\n");
}

char keyboard_get_scancode() {
    static const char scancode_to_ascii[128] = {
        0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 0, 0,
        'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 0, 0,
        'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0, '\\',
        'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, 0, 0, ' '
    };
    
    return scancode_to_ascii[inb(0x60)];
}

bool keyboard_getchar(char* c) {
    if (keyboard_buffer_pos > 0) {
        *c = keyboard_buffer[0];
        for (int i = 1; i < keyboard_buffer_pos; i++) {
            keyboard_buffer[i-1] = keyboard_buffer[i];
        }
        keyboard_buffer_pos--;
        return true;
    }
    return false;
}
