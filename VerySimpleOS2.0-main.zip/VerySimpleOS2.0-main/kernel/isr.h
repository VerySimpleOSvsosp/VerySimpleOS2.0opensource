#ifndef ISR_H
#define ISR_H

#include "types.h"

void isr_init();
void isr_install_handler(int isr, void (*handler)(struct regs *r));
void isr_uninstall_handler(int isr);

#endif
