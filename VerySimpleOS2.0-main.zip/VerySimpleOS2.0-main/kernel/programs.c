#include "programs.h"
#include "filesystem.h"
#include "stdio.h"
#include "string.h"

program_manager_t pm;

void pm_init() {
    memset(&pm, 0, sizeof(pm));
    
    // Предустановленные системные программы
    strcpy(pm.programs[pm.program_count].name, "File Manager");
    strcpy(pm.programs[pm.program_count].filename, "/System/fileman.app");
    pm.programs[pm.program_count].installed = true;
    pm.program_count++;
    
    strcpy(pm.programs[pm.program_count].name, "System Settings");
    strcpy(pm.programs[pm.program_count].filename, "/System/settings.app");
    pm.programs[pm.program_count].installed = true;
    pm.program_count++;
    
    printf("Program manager initialized: %d programs\n", pm.program_count);
}

bool install_program(const char* app_file, const char* program_name) {
    if (pm.program_count >= MAX_PROGRAMS) return false;
    
    file_entry_t* file = fs_find_file(app_file);
    if (!file) return false;
    
    strcpy(pm.programs[pm.program_count].name, program_name);
    strcpy(pm.programs[pm.program_count].filename, app_file);
    pm.programs[pm.program_count].installed = true;
    pm.program_count++;
    
    printf("Program installed: %s (%s)\n", program_name, app_file);
    return true;
}

bool uninstall_program(const char* program_name) {
    for (uint32_t i = 0; i < pm.program_count; i++) {
        if (strcmp(pm.programs[i].name, program_name) == 0 && pm.programs[i].installed) {
            pm.programs[i].installed = false;
            fs_delete_file(pm.programs[i].filename);
            printf("Program uninstalled: %s\n", program_name);
            return true;
        }
    }
    return false;
}

void launch_program(const char* program_name) {
    for (uint32_t i = 0; i < pm.program_count; i++) {
        if (strcmp(pm.programs[i].name, program_name) == 0 && pm.programs[i].installed) {
            pm.current_program = &pm.programs[i];
            pm.programs[i].running = true;
            
            uint8_t program_data[65536];
            uint32_t size = fs_read_file(pm.programs[i].filename, program_data, sizeof(program_data));
            
            if (size > 0) {
                printf("Launching program: %s\n", program_name);
                
                // Создание окна программы
                if (strcmp(program_name, "Notepad") == 0) {
                    open_notepad_window();
                } else if (strcmp(program_name, "Calculator") == 0) {
                    open_calculator_window();
                } else if (strcmp(program_name, "File Manager") == 0) {
                    open_filemanager_window();
                } else if (strcmp(program_name, "Web Browser") == 0) {
                    open_browser_window();
                } else if (strcmp(program_name, "Media Player") == 0) {
                    open_media_player();
                } else if (strcmp(program_name, "Terminal") == 0) {
                    open_terminal_window();
                }
            }
            break;
        }
    }
}

void terminate_program(const char* program_name) {
    for (uint32_t i = 0; i < pm.program_count; i++) {
        if (strcmp(pm.programs[i].name, program_name) == 0) {
            pm.programs[i].running = false;
            if (pm.current_program == &pm.programs[i]) {
                pm.current_program = NULL;
            }
            printf("Program terminated: %s\n", program_name);
            break;
        }
    }
}

void create_default_config() {
    // Создание стандартных программ
    uint8_t notepad_app[] = {0x90, 0x90, 0x90};
    uint8_t calculator_app[] = {0x90, 0x90, 0x90};
    uint8_t paint_app[] = {0x90, 0x90, 0x90};
    
    fs_write_file("/Programs/notepad.app", notepad_app, sizeof(notepad_app));
    fs_write_file("/Programs/calculator.app", calculator_app, sizeof(calculator_app));
    fs_write_file("/Programs/paint.app", paint_app, sizeof(paint_app));
    
    install_program("/Programs/notepad.app", "Notepad");
    install_program("/Programs/calculator.app", "Calculator");
    install_program("/Programs/paint.app", "Paint");
    
    const char* welcome_text = "Welcome to VerySimpleOS!\nThis is a sample document.";
    fs_write_file("/Documents/welcome.txt", (uint8_t*)welcome_text, strlen(welcome_text));
    
    printf("Default configuration created\n");
}
