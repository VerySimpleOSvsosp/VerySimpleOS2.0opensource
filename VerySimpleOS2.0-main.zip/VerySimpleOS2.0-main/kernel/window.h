#ifndef WINDOW_H
#define WINDOW_H

#include "types.h"

#define MAX_WINDOWS 10

typedef struct {
    uint16_t x, y;
    uint16_t width, height;
    char title[32];
    bool active;
    bool minimized;
    uint8_t type;
    void* window_data;
} window_t;

extern window_t windows[MAX_WINDOWS];
extern uint8_t window_count;
extern uint8_t active_window;

void window_init();
uint8_t create_window(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const char* title);
void close_window(uint8_t id);
void draw_window_frame(uint8_t id);
void draw_window_buttons(uint16_t x, uint16_t y);
void window_draw_all();
void activate_window(uint8_t id);
bool is_point_in_window(uint8_t id, uint16_t x, uint16_t y);

#endif
