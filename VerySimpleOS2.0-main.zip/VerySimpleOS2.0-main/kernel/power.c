#include "power.h"
#include "acpi.h"
#include "graphics.h"
#include "sound.h"
#include "stdio.h"
#include "window.h"

extern bool system_running;

void shutdown_computer() {
    printf("Initiating shutdown sequence...\n");
    
    play_system_sound(SOUND_SHUTDOWN);
    save_system_state();
    
    // Закрываем все окна
    for (int i = 0; i < window_count; i++) {
        if (windows[i].active) {
            close_window(i);
        }
    }
    
    draw_shutdown_screen();
    timer_wait(1000);
    
    if (!acpi_shutdown()) {
        printf("ACPI shutdown failed, using alternative method\n");
        alternative_shutdown();
    }
}

void reboot_computer() {
    printf("Rebooting system...\n");
    
    uint8_t temp;
    do {
        temp = inb(0x64);
        if ((temp & 0x02) == 0) break;
    } while (true);
    
    outb(0x64, 0xFE);
    asm volatile("hlt");
}

void draw_shutdown_screen() {
    fill_screen(0);
    
    draw_text(120, 80, "VerySimpleOS", 15);
    draw_text(110, 100, "Windows 96 Edition", 7);
    draw_text(100, 130, "It's now safe to turn off your computer.", 7);
    draw_text(140, 140, "Shutting down...", 7);
    
    for (int i = 0; i < 10; i++) {
        draw_text(150 + i * 8, 155, ".", 7);
        timer_wait(100);
    }
}

bool acpi_shutdown() {
    if (!acpi_detect()) {
        printf("ACPI not detected\n");
        return false;
    }
    
    uint16_t pm1a_cnt = inw(ACPI_PM1a_CNT);
    outw(ACPI_PM1a_CNT, ACPI_SLP_TYP | ACPI_SLP_EN);
    
    printf("ACPI shutdown command sent\n");
    return true;
}

void alternative_shutdown() {
    // Попытка выключения через APM
    outb(0xF4, 0x00);
    
    // Если не сработало - просто останавливаем процессор
    asm volatile("cli");
    asm volatile("hlt");
}
