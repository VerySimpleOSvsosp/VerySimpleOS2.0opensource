#include "isr.h"
#include "stdio.h"

void isr_init() {
    // Установка обработчиков прерываний
    printf("ISR initialized\n");
}

void isr_install_handler(int isr, void (*handler)(struct regs *r)) {
    // Установка пользовательского обработчика прерывания
}

void isr_uninstall_handler(int isr) {
    // Удаление обработчика прерывания
}
