#include "mouse.h"
#include "isr.h"
#include "stdio.h"

uint16_t mouse_x = 160, mouse_y = 100;
uint8_t mouse_buttons = 0;

void mouse_handler(struct regs *r) {
    static uint8_t mouse_cycle = 0;
    static int8_t mouse_byte[3];
    
    switch (mouse_cycle) {
        case 0:
            mouse_byte[0] = inb(0x60);
            mouse_cycle++;
            break;
        case 1:
            mouse_byte[1] = inb(0x60);
            mouse_cycle++;
            break;
        case 2:
            mouse_byte[2] = inb(0x60);
            
            mouse_x += mouse_byte[1];
            mouse_y -= mouse_byte[2];
            
            if (mouse_x > 319) mouse_x = 319;
            if (mouse_y > 199) mouse_y = 199;
            if (mouse_x < 0) mouse_x = 0;
            if (mouse_y < 0) mouse_y = 0;
            
            mouse_buttons = mouse_byte[0] & 0x07;
            mouse_cycle = 0;
            break;
    }
}

void mouse_init() {
    mouse_wait(1);
    outb(0x64, 0xA8);
    
    mouse_wait(1);
    outb(0x64, 0x20);
    mouse_wait(0);
    uint8_t status = inb(0x60) | 2;
    mouse_wait(1);
    outb(0x64, 0x60);
    mouse_wait(1);
    outb(0x60, status);
    
    mouse_write(0xF6);
    mouse_read();
    
    mouse_write(0xF4);
    mouse_read();
    
    isr_install_handler(44, mouse_handler);
    printf("Mouse initialized\n");
}

void mouse_wait(uint8_t a_type) {
    uint32_t timeout = 100000;
    if (a_type == 0) {
        while (timeout--) {
            if ((inb(0x64) & 1) == 1) return;
        }
    } else {
        while (timeout--) {
            if ((inb(0x64) & 2) == 0) return;
        }
    }
}

void mouse_write(uint8_t a_write) {
    mouse_wait(1);
    outb(0x64, 0xD4);
    mouse_wait(1);
    outb(0x60, a_write);
}

uint8_t mouse_read() {
    mouse_wait(0);
    return inb(0x60);
}

void mouse_get_position(uint16_t* x, uint16_t* y) {
    *x = mouse_x;
    *y = mouse_y;
}

bool mouse_get_buttons(uint8_t* buttons) {
    *buttons = mouse_buttons;
    return true;
}

void mouse_draw_cursor() {
    // Простой курсор мыши
    put_pixel(mouse_x, mouse_y, 15);
    put_pixel(mouse_x + 1, mouse_y, 15);
    put_pixel(mouse_x, mouse_y + 1, 15);
    put_pixel(mouse_x + 1, mouse_y + 1, 0);
}
