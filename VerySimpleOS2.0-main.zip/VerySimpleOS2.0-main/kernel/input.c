#include "input.h"
#include "keyboard.h"
#include "mouse.h"
#include "desktop.h"
#include "taskbar.h"
#include "window.h"

void input_init() {
    keyboard_init();
    mouse_init();
}

void input_handle() {
    char key;
    if (keyboard_getchar(&key)) {
        // Обработка нажатия клавиш
        if (active_window < window_count && windows[active_window].active) {
            // Передача ввода активному окну
        }
    }
    
    uint16_t mouse_x, mouse_y;
    uint8_t buttons;
    if (mouse_get_buttons(&buttons)) {
        mouse_get_position(&mouse_x, &mouse_y);
        
        if (buttons & 1) {
            if (mouse_y < SCREEN_HEIGHT - TASKBAR_HEIGHT) {
                desktop_handle_click(mouse_x, mouse_y);
            } else {
                taskbar_handle_click(mouse_x, mouse_y);
            }
        }
    }
}
