#include "config.h"
#include "filesystem.h"
#include "desktop.h"
#include "window.h"
#include "programs.h"
#include "stdio.h"
#include "string.h"

void save_system_state() {
    system_state_t state;
    memset(&state, 0, sizeof(state));
    
    state.desktop_color = 17;
    state.screen_width = 320;
    state.screen_height = 200;
    
    state.program_count = pm.program_count;
    for (uint32_t i = 0; i < pm.program_count; i++) {
        if (pm.programs[i].installed) {
            strcpy(state.installed_programs[i], pm.programs[i].name);
        }
    }
    
    state.window_count = window_count;
    for (uint32_t i = 0; i < window_count; i++) {
        if (windows[i].active) {
            state.windows[i].window_x = windows[i].x;
            state.windows[i].window_y = windows[i].y;
            state.windows[i].window_width = windows[i].width;
            state.windows[i].window_height = windows[i].height;
            strcpy(state.windows[i].window_title, windows[i].title);
            state.windows[i].window_visible = true;
        }
    }
    
    fs_write_file("/System/system.cfg", (uint8_t*)&state, sizeof(state));
    printf("System state saved\n");
}

bool load_system_state() {
    system_state_t state;
    uint32_t size = fs_read_file("/System/system.cfg", (uint8_t*)&state, sizeof(state));
    
    if (size != sizeof(state)) {
        printf("No saved system state found\n");
        return false;
    }
    
    for (uint32_t i = 0; i < state.program_count; i++) {
        install_program("/System/default.app", state.installed_programs[i]);
    }
    
    for (uint32_t i = 0; i < state.window_count; i++) {
        if (state.windows[i].window_visible) {
            create_window(state.windows[i].window_x, 
                         state.windows[i].window_y,
                         state.windows[i].window_width,
                         state.windows[i].window_height,
                         state.windows[i].window_title);
        }
    }
    
    printf("System state loaded: %d programs, %d windows\n", 
           state.program_count, state.window_count);
    return true;
}
