#include "memory.h"
#include "stdio.h"

static uint8_t memory_pool[MEMORY_POOL_SIZE];
static size_t next_free = 0;

void memory_init() {
    next_free = 0;
    printf("Memory manager initialized: %d KB available\n", MEMORY_POOL_SIZE / 1024);
}

void* malloc(size_t size) {
    if (next_free + size > MEMORY_POOL_SIZE) {
        return NULL;
    }
    
    void* ptr = &memory_pool[next_free];
    next_free += size;
    return ptr;
}

void free(void* ptr) {
    // Упрощенная реализация - в реальной ОС был бы сложный аллокатор
}

void* memset(void* dest, int val, size_t len) {
    uint8_t* ptr = (uint8_t*)dest;
    while (len-- > 0) {
        *ptr++ = val;
    }
    return dest;
}

void* memcpy(void* dest, const void* src, size_t len) {
    uint8_t* d = (uint8_t*)dest;
    const uint8_t* s = (const uint8_t*)src;
    while (len--) {
        *d++ = *s++;
    }
    return dest;
}
