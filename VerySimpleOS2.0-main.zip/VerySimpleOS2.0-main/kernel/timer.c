#include "timer.h"
#include "isr.h"
#include "stdio.h"

uint32_t timer_ticks = 0;

void timer_handler(struct regs *r) {
    timer_ticks++;
}

void timer_init(uint32_t frequency) {
    // Программирование таймера
    uint32_t divisor = 1193180 / frequency;
    
    outb(0x43, 0x36);
    outb(0x40, divisor & 0xFF);
    outb(0x40, divisor >> 8);
    
    isr_install_handler(32, timer_handler);
    printf("Timer initialized: %d Hz\n", frequency);
}

void timer_wait(uint32_t milliseconds) {
    uint32_t target = timer_ticks + milliseconds;
    while (timer_ticks < target);
}

uint32_t timer_get_ticks() {
    return timer_ticks;
}
