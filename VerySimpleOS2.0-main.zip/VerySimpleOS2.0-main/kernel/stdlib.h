#ifndef STDLIB_H
#define STDLIB_H

#include "types.h"

void* malloc(size_t size);
void free(void* ptr);
void exit(int status);
int atoi(const char* str);
char* itoa(int value, char* str, int base);

#endif
