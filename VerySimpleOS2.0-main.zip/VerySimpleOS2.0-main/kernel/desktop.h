#ifndef DESKTOP_H
#define DESKTOP_H

#include "types.h"

#define ICON_SIZE 32
#define ICON_SPACING 10

typedef struct {
    uint16_t x, y;
    char name[20];
    char program[20];
    bool selected;
} desktop_icon_t;

extern desktop_icon_t desktop_icons[10];
extern uint8_t icon_count;
extern bool show_start_menu;

void desktop_init();
void desktop_draw();
void desktop_handle_click(uint16_t x, uint16_t y);
void create_icon(uint16_t x, uint16_t y, const char* name, const char* program);
void draw_gradient_background();
void draw_icon(uint8_t icon_index);

#endif
