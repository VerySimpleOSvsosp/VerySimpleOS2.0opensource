#ifndef SB16_H
#define SB16_H

#include "types.h"

void sb16_init();
void sb16_play_sample(uint8_t* data, uint32_t length);
void sb16_stop_playback();
void sb16_set_sample_rate(uint16_t rate);

#endif
