#ifndef ACPI_H
#define ACPI_H

#include "types.h"

#define ACPI_PM1a_CNT 0x1004
#define ACPI_SLP_TYP 0x2000
#define ACPI_SLP_EN  (1 << 13)

bool acpi_detect();
bool acpi_shutdown();

#endif
