#ifndef VGA_H
#define VGA_H

#include "types.h"

void vga_init();
void vga_set_mode(uint8_t mode);
void vga_put_char(char c, uint8_t color, uint16_t x, uint16_t y);

#endif
