#include "sb16.h"
#include "timer.h"
#include "stdio.h"

void sb16_init() {
    // Сброс DSP
    outb(0x226, 0x01);
    timer_wait(10);
    outb(0x226, 0x00);
    
    // Ожидание готовности DSP
    timer_wait(100);
    
    // Проверка версии DSP
    outb(0x22C, 0xE1);
    uint8_t major = inb(0x22A);
    uint8_t minor = inb(0x22A);
    
    printf("Sound Blaster 16 detected: DSP v%d.%d\n", major, minor);
}

void sb16_play_sample(uint8_t* data, uint32_t length) {
    // Установка режима воспроизведения
    outb(0x22C, 0x41);
    outb(0x22C, 0x00);
    outb(0x22C, 0x00);
    
    // Передача данных
    for (uint32_t i = 0; i < length; i++) {
        outb(0x22C, data[i]);
    }
}

void sb16_stop_playback() {
    // Остановка воспроизведения
    outb(0x22C, 0xD0);
}

void sb16_set_sample_rate(uint16_t rate) {
    // Установка частоты дискретизации
    outb(0x22C, 0x41);
    outb(0x22C, rate >> 8);
    outb(0x22C, rate & 0xFF);
}
