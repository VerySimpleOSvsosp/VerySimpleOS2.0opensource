#include "ata.h"
#include "timer.h"
#include "stdio.h"

void ata_wait() {
    while (inb(ATA_STATUS) & 0x80);
}

bool ata_detect() {
    // Проверка наличия ATA диска
    outb(ATA_DRIVE_HEAD, 0xA0);
    timer_wait(1);
    
    if (inb(ATA_STATUS) == 0) {
        return false;
    }
    
    ata_wait();
    return true;
}

bool ata_read_sectors(uint32_t lba, uint8_t sectors, uint16_t* buffer) {
    ata_wait();
    
    outb(ATA_DRIVE_HEAD, 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_SECTOR_COUNT, sectors);
    outb(ATA_LBA_LOW, lba & 0xFF);
    outb(ATA_LBA_MID, (lba >> 8) & 0xFF);
    outb(ATA_LBA_HIGH, (lba >> 16) & 0xFF);
    outb(ATA_COMMAND, ATA_CMD_READ);
    
    for (int i = 0; i < sectors; i++) {
        ata_wait();
        if (inb(ATA_STATUS) & 0x01) {
            return false;
        }
        
        for (int j = 0; j < 256; j++) {
            buffer[i * 256 + j] = inw(ATA_DATA);
        }
    }
    return true;
}

bool ata_write_sectors(uint32_t lba, uint8_t sectors, uint16_t* buffer) {
    ata_wait();
    
    outb(ATA_DRIVE_HEAD, 0xE0 | ((lba >> 24) & 0x0F));
    outb(ATA_SECTOR_COUNT, sectors);
    outb(ATA_LBA_LOW, lba & 0xFF);
    outb(ATA_LBA_MID, (lba >> 8) & 0xFF);
    outb(ATA_LBA_HIGH, (lba >> 16) & 0xFF);
    outb(ATA_COMMAND, ATA_CMD_WRITE);
    
    for (int i = 0; i < sectors; i++) {
        ata_wait();
        if (inb(ATA_STATUS) & 0x01) {
            return false;
        }
        
        for (int j = 0; j < 256; j++) {
            outw(ATA_DATA, buffer[i * 256 + j]);
        }
    }
    return true;
}
