#include "vga.h"
#include "stdio.h"

void vga_init() {
    // Инициализация VGA контроллера
    outb(0x3C2, 0x63); // Miscellaneous Output Register
    
    // Sequence Controller
    outb(0x3C4, 0x01); outb(0x3C5, 0x01); // Synchronous Reset
    outb(0x3C4, 0x04); outb(0x3C5, 0x0E); // Memory Mode
    
    // CRT Controller
    outb(0x3D4, 0x11); outb(0x3D5, 0x0E); // Vertical Retrace End
    outb(0x3D4, 0x00); // Horizontal Total
    
    printf("VGA controller initialized\n");
}

void vga_set_mode(uint8_t mode) {
    asm volatile (
        "int $0x10"
        :
        : "a"(0x00 | mode)
        : "memory"
    );
}

void vga_put_char(char c, uint8_t color, uint16_t x, uint16_t y) {
    // Вывод символа в текстовом режиме (не используется в графическом режиме)
    uint16_t* video_memory = (uint16_t*)0xB8000;
    video_memory[y * 80 + x] = (color << 8) | c;
}
