#ifndef NE2000_H
#define NE2000_H

#include "types.h"

#define NE2000_BASE 0x300
#define NE2000_CMD NE2000_BASE + 0x00
#define NE2000_PSTART NE2000_BASE + 0x01
#define NE2000_BNRY NE2000_BASE + 0x03
#define NE2000_TPSR NE2000_BASE + 0x04
#define NE2000_TBCR0 NE2000_BASE + 0x05
#define NE2000_TBCR1 NE2000_BASE + 0x06
#define NE2000_ISR NE2000_BASE + 0x07
#define NE2000_RCR NE2000_BASE + 0x0C
#define NE2000_TCR NE2000_BASE + 0x0D
#define NE2000_DCR NE2000_BASE + 0x0E
#define NE2000_IMR NE2000_BASE + 0x0F

void ne2000_init();
bool ne2000_send_packet(uint8_t* data, uint16_t len);
uint16_t ne2000_receive_packet(uint8_t* buffer);

#endif
