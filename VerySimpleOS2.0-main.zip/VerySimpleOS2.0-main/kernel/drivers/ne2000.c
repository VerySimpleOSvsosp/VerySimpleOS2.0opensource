#include "ne2000.h"
#include "timer.h"
#include "stdio.h"

void ne2000_init() {
    // Сброс карты
    outb(NE2000_CMD, 0x21);
    timer_wait(10);
    outb(NE2000_CMD, 0x22);
    
    // Настройка регистров
    outb(NE2000_RCR, 0x04);
    outb(NE2000_TCR, 0x00);
    outb(NE2000_DCR, 0x48);
    outb(NE2000_IMR, 0x11);
    
    // Включение карты
    outb(NE2000_CMD, 0x22);
    
    printf("NE2000 network card initialized\n");
}

bool ne2000_send_packet(uint8_t* data, uint16_t len) {
    if (len > 1514) return false;
    
    // Ждем готовности карты
    while (inb(NE2000_CMD) & 0x04);
    
    // Устанавливаем начальную страницу передачи
    outb(NE2000_TPSR, 0x40);
    
    // Копируем данные в буфер карты
    for (uint16_t i = 0; i < len; i++) {
        outb(NE2000_BASE + 0x10, data[i]);
    }
    
    // Запускаем передачу
    outb(NE2000_TBCR0, len & 0xFF);
    outb(NE2000_TBCR1, len >> 8);
    outb(NE2000_CMD, 0x26);
    
    return true;
}

uint16_t ne2000_receive_packet(uint8_t* buffer) {
    // Проверяем есть ли принятые пакеты
    uint8_t isr = inb(NE2000_ISR);
    if (!(isr & 0x01)) return 0;
    
    // Читаем заголовок пакета
    uint8_t header[4];
    for (int i = 0; i < 4; i++) {
        header[i] = inb(NE2000_BASE + 0x10);
    }
    
    uint16_t packet_len = header[2] + (header[3] << 8) - 4;
    
    // Читаем данные пакета
    for (uint16_t i = 0; i < packet_len; i++) {
        buffer[i] = inb(NE2000_BASE + 0x10);
    }
    
    // Подтверждаем прием
    outb(NE2000_BNRY, header[1]);
    outb(NE2000_CMD, 0x22);
    
    return packet_len;
}
