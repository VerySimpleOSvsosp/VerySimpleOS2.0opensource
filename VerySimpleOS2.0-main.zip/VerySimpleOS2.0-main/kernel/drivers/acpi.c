#include "acpi.h"
#include "stdio.h"

bool acpi_detect() {
    // Проверка поддержки ACPI
    // Упрощенная проверка - в реальности здесь был бы поиск ACPI таблиц
    uint32_t signature = 0x20444352; // "RCD "
    
    // Проверяем наличие ACPI через мультибута или другие методы
    // Возвращаем true для демонстрации
    return true;
}

bool acpi_shutdown() {
    if (!acpi_detect()) {
        return false;
    }
    
    // Отправка команды выключения через ACPI
    uint16_t pm1a_cnt = inw(ACPI_PM1a_CNT);
    outw(ACPI_PM1a_CNT, ACPI_SLP_TYP | ACPI_SLP_EN);
    
    printf("ACPI shutdown command sent\n");
    return true;
}
