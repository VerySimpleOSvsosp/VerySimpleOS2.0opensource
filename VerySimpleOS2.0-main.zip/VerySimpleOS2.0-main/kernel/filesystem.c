#include "filesystem.h"
#include "ata.h"
#include "stdio.h"
#include "string.h"

filesystem_t fs;
bool virtual_fs_mode = true;

void fs_init() {
    // Пытаемся инициализировать реальную файловую систему
    if (ata_detect()) {
        virtual_fs_mode = false;
        printf("Real filesystem mode enabled\n");
    } else {
        virtual_fs_mode = true;
        memset(&fs, 0, sizeof(fs));
        fs.next_free_sector = 1;
        
        fs_create_file("C:", 0, 1);
        fs_create_file("/System", 0, 1);
        fs_create_file("/Programs", 0, 1);
        fs_create_file("/Documents", 0, 1);
        printf("Virtual filesystem mode enabled\n");
    }
}

bool fs_create_file(const char* filename, uint32_t size, uint8_t is_dir) {
    if (fs.file_count >= MAX_FILES) return false;
    
    strcpy(fs.files[fs.file_count].filename, filename);
    fs.files[fs.file_count].size = size;
    fs.files[fs.file_count].type = is_dir;
    fs.files[fs.file_count].start_sector = fs.next_free_sector;
    fs.files[fs.file_count].create_time = 0;
    
    fs.next_free_sector += (size + SECTOR_SIZE - 1) / SECTOR_SIZE;
    fs.file_count++;
    return true;
}

file_entry_t* fs_find_file(const char* filename) {
    for (uint32_t i = 0; i < fs.file_count; i++) {
        if (strcmp(fs.files[i].filename, filename) == 0) {
            return &fs.files[i];
        }
    }
    return NULL;
}

bool fs_write_file(const char* filename, const uint8_t* data, uint32_t size) {
    file_entry_t* file = fs_find_file(filename);
    if (!file) {
        file = fs_create_file(filename, size, 0);
        if (!file) return false;
    }
    
    if (size > MAX_FILE_SIZE) return false;
    
    uint32_t sector_offset = file->start_sector * SECTOR_SIZE;
    memcpy(&fs.storage[sector_offset], data, size);
    file->size = size;
    file->modify_time = 0;
    
    return true;
}

uint32_t fs_read_file(const char* filename, uint8_t* buffer, uint32_t max_size) {
    file_entry_t* file = fs_find_file(filename);
    if (!file || file->size == 0) return 0;
    
    uint32_t read_size = (file->size < max_size) ? file->size : max_size;
    uint32_t sector_offset = file->start_sector * SECTOR_SIZE;
    memcpy(buffer, &fs.storage[sector_offset], read_size);
    
    return read_size;
}

bool fs_delete_file(const char* filename) {
    for (uint32_t i = 0; i < fs.file_count; i++) {
        if (strcmp(fs.files[i].filename, filename) == 0) {
            fs.files[i].filename[0] = '\0';
            return true;
        }
    }
    return false;
}

bool fs_save_to_disk() {
    if (virtual_fs_mode) return false;
    
    // Сохранение файловой системы на реальный диск
    return true;
}
