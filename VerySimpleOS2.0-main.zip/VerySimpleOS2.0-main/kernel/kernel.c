#include "kernel.h"
#include "desktop.h"
#include "graphics.h"
#include "input.h"
#include "taskbar.h"
#include "network.h"
#include "sound.h"
#include "power.h"
#include "filesystem.h"
#include "programs.h"
#include "config.h"
#include "gdt.h"
#include "idt.h"
#include "isr.h"
#include "timer.h"
#include "keyboard.h"
#include "mouse.h"
#include "memory.h"
#include "stdio.h"

bool system_running = true;

void kernel_main() {
    // Инициализация базовых систем
    gdt_init();
    idt_init();
    isr_init();
    timer_init(100);
    keyboard_init();
    mouse_init();
    memory_init();

    // Инициализация файловой системы
    fs_init();

    // Инициализация менеджера программ
    pm_init();

    // Загрузка конфигурации
    if (!load_system_state()) {
        create_default_config();
    }

    // Инициализация графики
    gfx_init();
    desktop_init();

    // Инициализация звука
    sound_init();
    play_system_sound(SOUND_STARTUP);

    // Инициализация сети
    network_init();

    // Инициализация ввода
    input_init();

    printf("VerySimpleOS v1.0 initialized successfully\n");

    // Основной цикл
    while (system_running) {
        input_handle();
        desktop_draw();
        taskbar_draw();
        window_draw_all();
        mouse_draw_cursor();
        timer_wait(10);
    }

    // Завершение работы
    shutdown_computer();
}

void panic(const char* message) {
    printf("KERNEL PANIC: %s\n", message);
    asm volatile("cli");
    asm volatile("hlt");
}

void kprintf(const char* format, ...) {
    // Простая реализация форматированного вывода
    // (упрощенная версия)
    printf(format);
}
