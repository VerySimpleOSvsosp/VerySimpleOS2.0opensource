#ifndef KERNEL_H
#define KERNEL_H

#include "types.h"
#include "constants.h"

extern bool system_running;

void kernel_main();
void panic(const char* message);
void kprintf(const char* format, ...);

#endif
