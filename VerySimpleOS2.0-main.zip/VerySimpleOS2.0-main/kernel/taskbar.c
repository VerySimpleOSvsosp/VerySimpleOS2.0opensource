#include "taskbar.h"
#include "graphics.h"
#include "window.h"
#include "network.h"
#include "sound.h"
#include "power.h"
#include "stdio.h"

void taskbar_draw() {
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT, SCREEN_WIDTH, TASKBAR_HEIGHT, WIN96_TASK_BAR);
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT, SCREEN_WIDTH, 1, 15);
    
    draw_start_button();
    draw_taskbar_windows();
    draw_clock();
    draw_network_status();
    draw_sound_status();
    draw_power_buttons();
}

void draw_start_button() {
    draw_rect(2, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 45, 12, WIN96_TASK_BAR);
    draw_rect(2, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 45, 1, 15);
    draw_rect(2, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 1, 12, 15);
    draw_rect(46, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 1, 12, 8);
    draw_rect(2, SCREEN_HEIGHT - TASKBAR_HEIGHT + 13, 45, 1, 8);
    
    draw_text(8, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "Start", WIN96_TEXT_BLACK);
    
    draw_rect(4, SCREEN_HEIGHT - TASKBAR_HEIGHT + 5, 3, 3, 1);
    draw_rect(4, SCREEN_HEIGHT - TASKBAR_HEIGHT + 9, 3, 3, 1);
    draw_rect(8, SCREEN_HEIGHT - TASKBAR_HEIGHT + 5, 3, 3, 1);
    draw_rect(8, SCREEN_HEIGHT - TASKBAR_HEIGHT + 9, 3, 3, 1);
}

void draw_start_menu() {
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT - 120, 160, 120, WIN96_WINDOW_BG);
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT - 120, 160, 1, 15);
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT - 120, 1, 120, 15);
    draw_rect(159, SCREEN_HEIGHT - TASKBAR_HEIGHT - 120, 1, 120, 8);
    draw_rect(0, SCREEN_HEIGHT - TASKBAR_HEIGHT, 160, 1, 8);
    
    draw_text(10, SCREEN_HEIGHT - TASKBAR_HEIGHT - 116, "VerySimpleOS", WIN96_TEXT_BLACK);
    draw_rect(5, SCREEN_HEIGHT - TASKBAR_HEIGHT - 106, 150, 1, 8);
    
    const char* menu_items[] = {
        "Programs", "Documents", "Settings", "Find", 
        "Help", "Run...", "Shut Down..."
    };
    
    for (int i = 0; i < 7; i++) {
        uint16_t y = SCREEN_HEIGHT - TASKBAR_HEIGHT - 100 + i * 12;
        draw_text(10, y, menu_items[i], WIN96_TEXT_BLACK);
    }
}

void draw_clock() {
    draw_rect(SCREEN_WIDTH - 50, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 48, 12, WIN96_TASK_BAR);
    draw_text(SCREEN_WIDTH - 45, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "12:00 PM", WIN96_TEXT_BLACK);
}

void draw_network_status() {
    if (net_config.connected) {
        draw_rect(SCREEN_WIDTH - 100, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, 8, 8, 10);
        draw_text(SCREEN_WIDTH - 90, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "Online", WIN96_TEXT_BLACK);
    } else {
        draw_rect(SCREEN_WIDTH - 100, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, 8, 8, 12);
        draw_text(SCREEN_WIDTH - 90, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "Offline", WIN96_TEXT_BLACK);
    }
}

void draw_sound_status() {
    draw_rect(SCREEN_WIDTH - 150, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, 8, 8, 14);
    draw_text(SCREEN_WIDTH - 140, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "75%", WIN96_TEXT_BLACK);
}

void draw_power_buttons() {
    draw_rect(SCREEN_WIDTH - 200, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 12, 12, WIN96_TASK_BAR);
    draw_text(SCREEN_WIDTH - 198, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "⚡", WIN96_TEXT_BLACK);
    
    draw_rect(SCREEN_WIDTH - 185, SCREEN_HEIGHT - TASKBAR_HEIGHT + 2, 12, 12, WIN96_TASK_BAR);
    draw_text(SCREEN_WIDTH - 183, SCREEN_HEIGHT - TASKBAR_HEIGHT + 4, "↻", WIN96_TEXT_BLACK);
}

void taskbar_handle_click(uint16_t x, uint16_t y) {
    if (x >= 2 && x <= 47 && y >= SCREEN_HEIGHT - TASKBAR_HEIGHT + 2 && y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 14) {
        show_start_menu = !show_start_menu;
        return;
    }
    
    if (x >= SCREEN_WIDTH - 200 && x <= SCREEN_WIDTH - 188 && y >= SCREEN_HEIGHT - TASKBAR_HEIGHT + 2 && y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 14) {
        system_running = false;
    }
    
    if (x >= SCREEN_WIDTH - 185 && x <= SCREEN_WIDTH - 173 && y >= SCREEN_HEIGHT - TASKBAR_HEIGHT + 2 && y <= SCREEN_HEIGHT - TASKBAR_HEIGHT + 14) {
        reboot_computer();
    }
}

bool taskbar_is_point_in_menu(uint16_t x, uint16_t y) {
    return (x >= 0 && x <= 160 && y >= SCREEN_HEIGHT - TASKBAR_HEIGHT - 120 && y <= SCREEN_HEIGHT - TASKBAR_HEIGHT);
}
