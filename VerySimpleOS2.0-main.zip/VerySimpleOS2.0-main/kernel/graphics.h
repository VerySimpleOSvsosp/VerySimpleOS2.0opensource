#ifndef GRAPHICS_H
#define GRAPHICS_H

#include "types.h"

#define SCREEN_WIDTH 320
#define SCREEN_HEIGHT 200
#define VGA_MEMORY 0xA0000

extern uint8_t* vga_buffer;

void gfx_init();
void set_video_mode(uint16_t mode);
void put_pixel(uint16_t x, uint16_t y, uint8_t color);
void draw_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t color);
void draw_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint8_t color);
void draw_circle(uint16_t x, uint16_t y, uint16_t radius, uint8_t color);
void draw_text(uint16_t x, uint16_t y, const char* text, uint8_t color);
void draw_char(uint16_t x, uint16_t y, char c, uint8_t color);
void fill_screen(uint8_t color);
void clear_screen();

#endif
