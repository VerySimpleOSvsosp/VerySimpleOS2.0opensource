#include "desktop.h"
#include "graphics.h"
#include "window.h"
#include "programs.h"
#include "network.h"
#include "sound.h"
#include "stdio.h"

desktop_icon_t desktop_icons[10];
uint8_t icon_count = 0;
bool show_start_menu = false;

void desktop_init() {
    create_icon(20, 30, "My Computer", "explorer");
    create_icon(20, 80, "Recycle Bin", "recycle");
    create_icon(20, 130, "Network", "network");
    create_icon(100, 30, "Notepad", "notepad");
    create_icon(100, 80, "Calculator", "calculator");
    create_icon(100, 130, "Paint", "paint");
    create_icon(180, 30, "Media Player", "mediaplayer");
    create_icon(180, 80, "Web Browser", "browser");
    create_icon(180, 130, "Terminal", "terminal");
}

void create_icon(uint16_t x, uint16_t y, const char* name, const char* program) {
    if (icon_count >= 10) return;
    
    desktop_icons[icon_count].x = x;
    desktop_icons[icon_count].y = y;
    strcpy(desktop_icons[icon_count].name, name);
    strcpy(desktop_icons[icon_count].program, program);
    desktop_icons[icon_count].selected = false;
    icon_count++;
}

void desktop_draw() {
    draw_gradient_background();
    
    for (int i = 0; i < icon_count; i++) {
        draw_icon(i);
    }
}

void draw_gradient_background() {
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        uint8_t color = WIN96_DESKTOP_BLUE + (y / 25);
        if (color > 23) color = 23;
        
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            put_pixel(x, y, color);
        }
    }
}

void draw_icon(uint8_t icon_index) {
    desktop_icon_t* icon = &desktop_icons[icon_index];
    
    if (icon->selected) {
        draw_rect(icon->x-2, icon->y-2, ICON_SIZE+4, ICON_SIZE+4, 15);
    }
    
    draw_icon_shape(icon->x, icon->y, icon->program);
    
    uint16_t text_x = icon->x - (strlen(icon->name) * 4) + 16;
    draw_text(text_x, icon->y + ICON_SIZE + 5, icon->name, 
              icon->selected ? 15 : 7);
}

void draw_icon_shape(uint16_t x, uint16_t y, const char* type) {
    if (strcmp(type, "explorer") == 0) {
        draw_rect(x+8, y+4, 16, 12, 15);
        draw_rect(x+4, y+16, 24, 12, 8);
        draw_rect(x+12, y+28, 8, 4, 6);
    } else if (strcmp(type, "notepad") == 0) {
        draw_rect(x+4, y+4, 24, 20, 15);
        draw_line(x+8, y+8, x+20, y+8, 0);
        draw_line(x+8, y+12, x+20, y+12, 0);
        draw_line(x+8, y+16, x+16, y+16, 0);
    }
    // ... другие иконки
}

void desktop_handle_click(uint16_t x, uint16_t y) {
    for (int i = 0; i < icon_count; i++) {
        desktop_icons[i].selected = false;
    }
    
    for (int i = 0; i < icon_count; i++) {
        desktop_icon_t* icon = &desktop_icons[i];
        
        if (x >= icon->x && x <= icon->x + ICON_SIZE &&
            y >= icon->y && y <= icon->y + ICON_SIZE + 20) {
            
            icon->selected = true;
            
            static uint32_t last_click_time = 0;
            uint32_t current_time = timer_get_ticks();
            
            if (current_time - last_click_time < 500) {
                launch_program(icon->program);
            }
            
            last_click_time = current_time;
            return;
        }
    }
    
    if (show_start_menu && !taskbar_is_point_in_menu(x, y)) {
        show_start_menu = false;
    }
}
