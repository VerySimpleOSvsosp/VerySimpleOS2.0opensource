#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include "types.h"

#define MAX_FILES 100
#define MAX_FILENAME 32
#define MAX_FILE_SIZE 65536
#define SECTOR_SIZE 512

typedef struct {
    char filename[MAX_FILENAME];
    uint32_t size;
    uint32_t start_sector;
    uint8_t type;
    uint32_t create_time;
    uint32_t modify_time;
} file_entry_t;

typedef struct {
    file_entry_t files[MAX_FILES];
    uint32_t file_count;
    uint8_t storage[1024 * 1024];
    uint32_t next_free_sector;
} filesystem_t;

extern filesystem_t fs;
extern bool virtual_fs_mode;

void fs_init();
bool fs_create_file(const char* filename, uint32_t size, uint8_t is_dir);
file_entry_t* fs_find_file(const char* filename);
bool fs_write_file(const char* filename, const uint8_t* data, uint32_t size);
uint32_t fs_read_file(const char* filename, uint8_t* buffer, uint32_t max_size);
bool fs_delete_file(const char* filename);
bool fs_save_to_disk();

#endif
