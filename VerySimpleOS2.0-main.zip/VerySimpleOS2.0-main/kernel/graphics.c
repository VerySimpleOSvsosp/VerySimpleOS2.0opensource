#include "graphics.h"
#include "string.h"

uint8_t* vga_buffer = (uint8_t*)VGA_MEMORY;

void gfx_init() {
    set_video_mode(0x13);
}

void set_video_mode(uint16_t mode) {
    asm volatile (
        "int $0x10"
        :
        : "a"(0x13)
        : "memory"
    );
}

void put_pixel(uint16_t x, uint16_t y, uint8_t color) {
    if (x < SCREEN_WIDTH && y < SCREEN_HEIGHT) {
        vga_buffer[y * SCREEN_WIDTH + x] = color;
    }
}

void draw_rect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t color) {
    for (uint16_t i = y; i < y + h && i < SCREEN_HEIGHT; i++) {
        for (uint16_t j = x; j < x + w && j < SCREEN_WIDTH; j++) {
            vga_buffer[i * SCREEN_WIDTH + j] = color;
        }
    }
}

void draw_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint8_t color) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int sx = (x1 < x2) ? 1 : -1;
    int sy = (y1 < y2) ? 1 : -1;
    int err = dx - dy;

    while (1) {
        put_pixel(x1, y1, color);
        if (x1 == x2 && y1 == y2) break;
        int e2 = 2 * err;
        if (e2 > -dy) {
            err -= dy;
            x1 += sx;
        }
        if (e2 < dx) {
            err += dx;
            y1 += sy;
        }
    }
}

void draw_text(uint16_t x, uint16_t y, const char* text, uint8_t color) {
    while (*text) {
        draw_char(x, y, *text, color);
        x += 8;
        text++;
        if (x > SCREEN_WIDTH - 8) break;
    }
}

void draw_char(uint16_t x, uint16_t y, char c, uint8_t color) {
    // Простой шрифт 8x8
    const uint8_t font[128][8] = {
        [32] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
        [65] = {0x18, 0x3C, 0x66, 0x7E, 0x66, 0x66, 0x66, 0x00},
        // ... остальные символы
    };

    if (c < 32 || c > 126) return;
    
    const uint8_t* glyph = font[(int)c];
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (glyph[i] & (1 << (7 - j))) {
                put_pixel(x + j, y + i, color);
            }
        }
    }
}

void fill_screen(uint8_t color) {
    for (int i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
        vga_buffer[i] = color;
    }
}

void clear_screen() {
    fill_screen(0);
}
