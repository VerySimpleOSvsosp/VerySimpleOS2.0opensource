#ifndef TASKBAR_H
#define TASKBAR_H

#include "types.h"

#define TASKBAR_HEIGHT 16

void taskbar_draw();
void taskbar_handle_click(uint16_t x, uint16_t y);
void draw_start_button();
void draw_start_menu();
void draw_taskbar_windows();
void draw_clock();
void draw_network_status();
void draw_sound_status();
void draw_power_buttons();
bool taskbar_is_point_in_menu(uint16_t x, uint16_t y);

#endif
