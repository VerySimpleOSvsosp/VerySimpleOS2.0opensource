#ifndef POWER_H
#define POWER_H

#include "types.h"

void shutdown_computer();
void reboot_computer();
void draw_shutdown_screen();
bool acpi_shutdown();
void alternative_shutdown();

#endif
