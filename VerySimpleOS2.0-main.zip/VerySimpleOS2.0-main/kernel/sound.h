#ifndef SOUND_H
#define SOUND_H

#include "types.h"

#define SAMPLE_RATE 22050
#define AUDIO_BUFFER_SIZE 4096

typedef enum {
    SOUND_STARTUP,
    SOUND_CLICK,
    SOUND_ERROR,
    SOUND_SHUTDOWN
} sound_type_t;

typedef struct {
    uint16_t sample_rate;
    uint8_t channels;
    uint8_t bits_per_sample;
    bool playing;
    uint32_t position;
    uint8_t buffer[AUDIO_BUFFER_SIZE];
} audio_state_t;

extern audio_state_t audio;

void sound_init();
void play_sound(uint8_t* wave_data, uint32_t length);
void stop_sound();
void play_system_sound(sound_type_t sound_type);
void generate_sine_wave(uint8_t* buffer, uint32_t length, uint16_t frequency, uint8_t volume);
void sound_thread();

#endif
