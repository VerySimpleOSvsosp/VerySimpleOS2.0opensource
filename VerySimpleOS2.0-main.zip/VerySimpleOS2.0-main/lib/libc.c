#include "libc.h"
#include "string.h"
#include "memory.h"

// Стандартные функции libc
int memcmp(const void* s1, const void* s2, size_t n) {
    const unsigned char* p1 = s1;
    const unsigned char* p2 = s2;
    
    while (n--) {
        if (*p1 != *p2) {
            return *p1 - *p2;
        }
        p1++;
        p2++;
    }
    return 0;
}

char* strcat(char* dest, const char* src) {
    char* ptr = dest + strlen(dest);
    while (*src) {
        *ptr++ = *src++;
    }
    *ptr = '\0';
    return dest;
}

char* strchr(const char* s, int c) {
    while (*s) {
        if (*s == c) {
            return (char*)s;
        }
        s++;
    }
    return NULL;
}

size_t strspn(const char* s, const char* accept) {
    size_t count = 0;
    while (*s && strchr(accept, *s)) {
        count++;
        s++;
    }
    return count;
}

size_t strcspn(const char* s, const char* reject) {
    size_t count = 0;
    while (*s && !strchr(reject, *s)) {
        count++;
        s++;
    }
    return count;
}

char* strtok(char* str, const char* delim) {
    static char* saved_ptr = NULL;
    
    if (str) {
        saved_ptr = str;
    }
    
    if (!saved_ptr || !*saved_ptr) {
        return NULL;
    }
    
    // Пропускаем начальные разделители
    saved_ptr += strspn(saved_ptr, delim);
    if (!*saved_ptr) {
        return NULL;
    }
    
    char* token_start = saved_ptr;
    saved_ptr += strcspn(saved_ptr, delim);
    
    if (*saved_ptr) {
        *saved_ptr++ = '\0';
    }
    
    return token_start;
}
