#ifndef SHELL_H
#define SHELL_H

#include "types.h"

void shell_init();
void shell_execute(const char* command);
void shell_print(const char* text);

#endif
