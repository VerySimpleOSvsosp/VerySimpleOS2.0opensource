#include "shell.h"
#include "stdio.h"
#include "string.h"
#include "commands.h"

static char shell_buffer[256];
static uint16_t shell_pos = 0;

void shell_init() {
    printf("VerySimpleOS Shell v1.0\n");
    printf("Type 'help' for available commands\n");
    shell_print("C:\\> ");
}

void shell_execute(const char* command) {
    if (strcmp(command, "help") == 0) {
        cmd_help();
    } else if (strcmp(command, "clear") == 0) {
        cmd_clear();
    } else if (strcmp(command, "time") == 0) {
        cmd_time();
    } else if (strcmp(command, "network") == 0) {
        cmd_network();
    } else if (strcmp(command, "sound") == 0) {
        cmd_sound();
    } else if (strcmp(command, "shutdown") == 0) {
        cmd_shutdown();
    } else {
        printf("Unknown command: %s\n", command);
    }
    
    shell_print("C:\\> ");
}

void shell_print(const char* text) {
    printf("%s", text);
}
