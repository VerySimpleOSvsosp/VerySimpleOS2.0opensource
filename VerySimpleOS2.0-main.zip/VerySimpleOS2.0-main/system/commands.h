#ifndef COMMANDS_H
#define COMMANDS_H

#include "types.h"

void cmd_help();
void cmd_clear();
void cmd_time();
void cmd_network();
void cmd_sound();
void cmd_shutdown();

#endif
