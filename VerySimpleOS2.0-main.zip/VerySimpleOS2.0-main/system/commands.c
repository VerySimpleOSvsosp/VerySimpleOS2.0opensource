#include "commands.h"
#include "stdio.h"
#include "network.h"
#include "sound.h"
#include "power.h"

void cmd_help() {
    printf("Available commands:\n");
    printf("  help      - Show this help\n");
    printf("  clear     - Clear screen\n");
    printf("  time      - Show current time\n");
    printf("  network   - Show network information\n");
    printf("  sound     - Test sound system\n");
    printf("  shutdown  - Shutdown computer\n");
}

void cmd_clear() {
    // Очистка экрана
    fill_screen(0);
}

void cmd_time() {
    printf("Current system time: 12:00 PM\n");
}

void cmd_network() {
    printf("Network Information:\n");
    printf("  Status: %s\n", net_config.connected ? "Connected" : "Disconnected");
    printf("  IP: %d.%d.%d.%d\n", 
           (net_config.ip >> 24) & 0xFF, (net_config.ip >> 16) & 0xFF,
           (net_config.ip >> 8) & 0xFF, net_config.ip & 0xFF);
}

void cmd_sound() {
    printf("Testing sound system...\n");
    play_system_sound(SOUND_STARTUP);
}

void cmd_shutdown() {
    printf("Initiating shutdown...\n");
    shutdown_computer();
}
